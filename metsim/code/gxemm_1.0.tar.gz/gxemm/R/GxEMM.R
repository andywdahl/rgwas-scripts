GxEMM	<- function(
	y, X=NULL, K, Z=NULL,
	gtype=c('hom','iid','free')[1], etype=c('hom','free')[1],
	binary=FALSE, prev,
	#trunc=FALSE,
	ldak_loc='~/GxEMM/code/ldak5.linux ',
	lowmem=FALSE,
	tmpdir=paste0( 'gxemm_tmp_', round( abs(rnorm(1) + X[sample(10,1)] + y[sample(10,1)] )*1e5, 0 ) ),
	keep_ldak=FALSE
){
	if(keep_ldak){
		outdir=paste0( 'gxemm_out_', round( abs(rnorm(1) + X[sample(10,1)] + y[sample(10,1)] )*1e5, 0 ) )
	} else {
		outdir=tmpdir
	}
	Z		<- as.matrix(Z)
	X		<- as.matrix(X)
	K0	<- ncol(Z)

	#### check not already ran
	if( file.exists( paste0( tmpdir, '/y.phen' ) ) ) stop('Output file already exists')
	system( paste0( 'mkdir ', tmpdir ) )
	if( tmpdir != outdir )
	system( paste0( 'mkdir ', outdir ) )


print( 'aaaa' )
	### write pheno + covars
	if( binary ){
		stopifnot( all( is.na(y) | (y%in%1:2) ) )
		if( missing( prev ) ){
			warning( 'Prevalence missing. Assuming binary trait isn\'t scertained, which fails badly for rare disease case/control data' )
			prev	<- sum(y==2)/sum(y%in%1:2)
		}
	} else {
		y	<- scale(y)
	}
print( 'bbbb' )
	write_pheno( y, file=paste0( tmpdir, '/y.phen')	 )
	write_pheno( X, file=paste0( tmpdir, '/X.qcovar') )
	X0			<- cbind( 1, X )
	rm(y,X); gc()

print( 'cccc' )
	X_singvals	<- svd(X0)$d
	if( max(X_singvals)/min(X_singvals) > 1e4 )
		stop( 'cbind(1,X) is nearly collinear; either X should be scaled or a column should be dropped' )

	### write each of the kinship matrices
print( 'dddd' )
	ws	<- write_kin( tmpdir, K, index=1, ldak_loc, X0 )
	if( gtype == 'iid' ){
		ws	<- c( ws, write_kin( tmpdir, K * (Z %*% t(Z)), index=2, ldak_loc, X0 ) )
	} else if( gtype == 'free' ){
		for( k in 1:K0 )
			ws	<- c( ws, write_kin( tmpdir, K * ( Z[,k,drop=F] %*% t(Z[,k,drop=F])	), index=1+k, ldak_loc, X0 ) )
	}
	rm(K); gc()
	if( etype == 'free' )
		for( k in 1:ifelse( binary, K0, K0-1 ) )
			ws	<- c( ws, write_kin( tmpdir, diag( Z[,k]^2 ), index=length(ws)+1, ldak_loc, X0 ) )
	rm(Z); gc()
	r		<- length(ws)
	ws	<- c( ws, 1 - ncol(X0)/nrow(X0) )
	write.table( paste0( tmpdir, '/K.', 1:r ), file=paste0( tmpdir, '/multi_grm.txt' ), sep='\t', row.names=F, col.names=F, quote=F )

print( 'eeee' )
	if( binary )
		for( i in 1:r )
			adjust_ldak_kinship( prefix=paste0( tmpdir, '/K.', i ), ldak_loc, covarfile=paste0( tmpdir, '/X.qcovar ' ) )

print( 'uuuu' )
	failed	<- TRUE
	try({
		system( paste0( ldak_loc,
			ifelse( r==1, 
				paste0(	' --grm ', tmpdir, '/K.1 '  ),
				paste0( ' --mgrm ', tmpdir, '/multi_grm.txt ' )
			), 
			' --pheno ', tmpdir, '/y.phen ',
			' --covar ', tmpdir, '/X.qcovar ',
			ifelse( binary, ' --pcgc ', ' --reml ' ), outdir, '/tmp',
			ifelse( binary, paste0( ' --prevalence ', prev ), '' ),
			#ifelse( ! trunc, '', ' not done ' ),
			' --memory-save ', ifelse( lowmem , 'YES ', 'NO ' ),
			' --kinship-details NO'
		))
		gout	<- extract_ldak( binary, outdir, ws, r )
		failed	<- FALSE
	})
	system( paste0( 'rm -rf ', tmpdir ) )
	if( failed ) return('FAILED')
	
	sig2s	<- gout$sig2s[1:(r+1)]
	ses		<- gout$ses[1:(r+1)]

	h2names	<- paste0( 'h2_', 1:K0 )
	if( gtype == 'hom' & etype == 'hom' ){
		h2names	<- 'hom'
		h2			<- sig2s[1]/sum(sig2s) 
		h2Covmat<- matrix( ses[1]^2, 1, 1 )

	} else if( gtype == 'iid' ){
		if( etype == 'free' ) stop('No iid + het noise implemented yet')
		h2names	<- c( 'hom', 'het' )
		h2			<- sig2s[1:2]/sum(sig2s)
		form		<- list(
			as.formula("~(x1)/(x1+x2+x3)"),
			as.formula("~(x2)/(x1+x2+x3)")
		)

	} else if( gtype == 'hom' & etype == 'free' ){
		if( binary ){
			h2	<- sapply( 1:K0, function(k)
				sig2s[1]/sum(sig2s[c(1,1+k,r+1)])
			)
			form<- lapply( 1:K0, function(k) as.formula( paste0(
				'~x1/(x1+x',1+k,'+x',r+1,')'
			) ) )
		} else {
			h2	<- sapply( 1:K0, function(k)
				sig2s[1]/(sum(sig2s[c(1,r+1)]) + ifelse( k==K0, 0, sig2s[1+k] ))
			)
			form<- lapply( 1:K0, function(k) as.formula( paste0(
				'~x1/(x1+x', ifelse( k==K0, paste0(1+k,'+x'), '' ), 1+r, ')'
			) ) )
		}

	} else if( gtype == 'free' & etype == 'free' ){
		if( binary ){
			h2	<- sapply( 1:K0, function(k)
				sum(sig2s[c(1,1+k)])/sum(sig2s[c(1,1+k,1+K0+k,r+1)])
			)
			form<- lapply( 1:K0, function(k) as.formula( paste0(
				'~(x1+x', 1+k, ')/(x1+x', 1+k, '+x', 1+K0+k,'+x', r+1, ')'
			) ) )
		} else {
			h2	<- sapply( 1:K0, function(k)
				sum(sig2s[c(1,1+k)])/(sum(sig2s[c(1,1+k,r+1)]) + ifelse( k==K0, 0, sig2s[1+K0+k] ))
			)
			form<- lapply( 1:K0, function(k) as.formula( paste0(
				'~(x1+x', 1+k, ')/(x1+x', 1+k, '+x', ifelse( k==K0, '', paste0(1+K0+k,'+x') ), r+1, ')'
			) ) )
		}

	} else if( gtype == 'free' & etype == 'hom' ){
		h2	<- sapply( 1:K0, function(k) sum( sig2s[c(1,1+k)] )/sum( sig2s[c(1,1+k,r+1)] ) )
		form<- lapply( 1:K0, function(k) as.formula(paste0( '~(x1+x', 1+k, ')/(x1+x', 1+k, '+x', r+1, ')')) )

	} else {
		stop(c(gtype,etype))
	}
	if(!( gtype == 'hom' & etype == 'hom' ))
	h2Covmat	<- msm::deltamethod( form, sig2s, gout$sig2Var, ses=F )
	
	names(h2)	<- h2names

	list( h2=h2, h2Covmat=h2Covmat, df=r, ll=gout$ll, sig2s=sig2s, sig2Var=gout$sig2Var, mus=gout$mus, betas=gout$betas )
}
